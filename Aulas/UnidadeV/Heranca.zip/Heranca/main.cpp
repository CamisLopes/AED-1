#include "restaurante.h"

int main(){
    Restaurante rest("O Melhor Restaurante", "Avenida Lá Perto", "Cidade Linda", "General Mines", 
                    "00000-000", "0000-0000", 10, 5.00);
    rest.print();
    return 0;
}